To install the Notepad++ BGScript Highlighter:

1.	Open Notepad++
2.	In the 'Language' menu, click 'Define your language...'
3.	Click 'Import...' and select the 'userDefineLang_BGScript.xml' file
4.	Copy 'BGScript.xml' file to '<NPP-Install-Dir>\plugins\APIs'
5.	In the 'Settings' menu, click 'Preferences...', then 'Backup/Autocompletion'
6.	Enable Auto-Completion options if desired

Two things to note:

a. If you already have a BGScript user-defined language in Notepad++, you MUST
   remove it first.
   
b. The 'APIs' folder is typically found at 'C:\Program Files\Notepad++\plugins\APIs'.
