//
//  BLEMailboxAppDelegate.h
//  BLEMailbox
//
//  Created by Jeff Rowberg on 1/12/13.
//  Copyright (c) 2013 Jetney Development. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BLEMailboxAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
