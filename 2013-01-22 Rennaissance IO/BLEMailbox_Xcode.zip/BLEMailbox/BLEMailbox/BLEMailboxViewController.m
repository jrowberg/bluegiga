//
//  BLEMailboxViewController.m
//  BLEMailbox
//
//  Created by Jeff Rowberg on 1/12/13.
//  Copyright (c) 2013 Jetney Development. All rights reserved.
//

#import "BLEMailboxViewController.h"

@interface BLEMailboxViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *statusImage;
@property (weak, nonatomic) IBOutlet UILabel *mailboxStatus;
@property (weak, nonatomic) IBOutlet UILabel *mailboxCount;
@property (weak, nonatomic) IBOutlet UILabel *bleConnection;

@end

static NSString * const kMailboxServiceUUID =                       @"E4888211-50F0-412D-9C9A-75015EB26586";
static NSString * const kMailboxRecordCharacteristicUUID =          @"F74E34E2-2B9F-4441-B068-A4FB7BD78374";
static NSString * const kMailboxRecordControlCharacteristicUUID =   @"9887B262-002B-4361-9F46-8E3DF29CB082";

static NSString * const kTimesyncServiceUUID =                      @"64E9837D-CA48-48C4-BB71-323E5A85B51F";
static NSString * const kTimesyncCharacteristicUUID =               @"51686B01-7B48-4675-891C-DDC7C4B36E66";

@implementation BLEMailboxViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.mailboxCount.text = @"Delivery: Waiting for info...";
    self.mailboxCount.textColor = [UIColor blackColor];
    self.mailboxCount.backgroundColor = [UIColor yellowColor];

    self.mailboxStatus.text = @"Mailbox: Waiting for info...";
    self.mailboxStatus.textColor = [UIColor blackColor];
    self.mailboxStatus.backgroundColor = [UIColor yellowColor];
    
    self.bleConnection.text = @"Scanning...";

    self.manager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)centralManagerDidUpdateState:(CBCentralManager *)central {
    switch (central.state) {
        case CBCentralManagerStatePoweredOn:
            // scans for any peripheral
            [self.manager scanForPeripheralsWithServices:@[ [CBUUID UUIDWithString:kMailboxServiceUUID] ] options:@{CBCentralManagerScanOptionAllowDuplicatesKey : @YES }];
            NSLog(@"Central Manager state powered on");
            break;
        default:
            NSLog(@"Central Manager did update state");
            break;
    }
}

- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI {
    NSLog(@"Found peripheral %@", peripheral);
    NSLog(@"Advertisement data: %@", advertisementData);

    NSData *mfrData = [advertisementData valueForKey:@"kCBAdvDataManufacturerData"];
    NSLog(@"Manufacturer data: %@", mfrData);

    unsigned char mailboxData[3];
    NSRange mailboxRange = {2, 3};
    [mfrData getBytes:mailboxData range:mailboxRange];
    NSLog(@"Mailbox count: %d", mailboxData[0]);
    NSLog(@"Mailbox status: %d", mailboxData[1]);
    NSLog(@"Mailbox light level: %d", mailboxData[2]);
    
    if (mailboxData[0] == 0) {
        // no mail arrived since last check
        self.mailboxCount.text = @"Delivery: No Mail";
        self.mailboxCount.textColor = [UIColor whiteColor];
        self.mailboxCount.backgroundColor = [UIColor redColor];
    } else {
        // mail has arrived since last check
        self.mailboxCount.text = @"Delivery: Delivered";
        self.mailboxCount.textColor = [UIColor blackColor];
        self.mailboxCount.backgroundColor = [UIColor greenColor];
    }
    
    if (mailboxData[1] == 0) {
        // mailbox currently closed
        self.mailboxStatus.text = @"Mailbox: Closed";
        self.mailboxStatus.textColor = [UIColor whiteColor];
        self.mailboxStatus.backgroundColor = [UIColor redColor];
        if (mailboxData[0] == 0) {
            self.statusImage.image = [UIImage imageNamed:@"blemailbox-closed-empty.png"];
        } else {
            self.statusImage.image = [UIImage imageNamed:@"blemailbox-closed-full"];
        }
    } else {
        // mailbox currently open
        self.mailboxStatus.text = @"Mailbox: Open";
        self.mailboxStatus.textColor = [UIColor blackColor];
        self.mailboxStatus.backgroundColor = [UIColor greenColor];
        self.statusImage.image = [UIImage imageNamed:@"blemailbox-open-empty.png"];
    }

    self.bleConnection.text = [NSString stringWithFormat:@"Found sensor (RSSI=%@)", RSSI];
    
    // stops scanning for peripheral
    //[self.manager stopScan];
    
    /*if (self.peripheral != peripheral) {
        self.peripheral = peripheral;
        NSLog(@"Connecting to peripheral %@", peripheral);
        // Connects to the discovered peripheral
        [self.manager connectPeripheral:peripheral options:nil];
    }*/
}



@end
